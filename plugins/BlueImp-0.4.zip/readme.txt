CFWheels plugin for BlueImp

Third party software used:
http://blueimp.github.com/jQuery-File-Upload/ (contained in plugin)
http://jquery.com/

Requires:
# Wheels 1.1.6, 1.1.7
# jQuery 1.7.1
 
TO USE
1) Place the BlueImp-X.X.zip in your plugins folder

2) Reload your Wheels application.
Example: http://localhost/index.cfm?reload=true

You should be good to go now.

EXAMPLES OF USE

Basic Usage:

#blueImpMultiFile(controller="controllerName", action="fileUploadProcess", key="key")#

Note that the parameters are the same as startFormTag with an extra param called headFlag on whether to load the css and js files blueImp Needs.

And in the controller the function should look like (Note attachmentsData variable should be a list of filePaths stored in the table or similar):

<cffunction name="fileUpload">
	<!--- Load the data for the object the files are attached to, in this case the list of filePaths into attachmentsData --->
	<cfif GetHttpRequestData().method EQ "GET">
		<cfscript>
			var result = ArrayNew();
			for(i = 1; i LTE ListLen(attachmentsData, ";"); i++){
				var urlpath = ListGetAt(attachmentsData, i, ";");
				var fileInfo = GetFileInfo(urlpath);
				result.append({
					"name":			fileInfo.Name,
					"size":			fileInfo.Size,
					"url":			urlpath,
					"deleteurl":	URLfor(action="fileUpload", key=params.key, method="DELETE", params="file=#urlpath#"),
					"deletetype":	"DELETE"
				});
			}
		</cfscript>
	<cfelseif GetHttpRequestData().method EQ "POST">
		<cffile action="upload" fileField="files[]" destination="#ExpandPath('/files/uploads')#" nameConflict="makeUnique" result="upload">
		<cfset var urlPath = "#SERVER.separator.file#files#SERVER.separator.file#uploads#SERVER.separator.file##upload.serverfile#">
		<cfset thisNote.update(attachments="#urlPath#;#attachmentsData#")>
		<cfscript>
			result = [{
				"name":			upload.serverfile,
				"size":			upload.filesize,
				"url":			urlPath,
				"deleteurl":	URLfor(action="fileUpload", key=params.key, method="DELETE", params="file=#urlpath#"),
				"deletetype":	"DELETE"
			}];
		</cfscript>
	<cfelseif GetHttpRequestData().method EQ "DELETE">
		<cffile action="delete" file="#ExpandPath('/#URL.file#')#">
		<cfset attachments = ListDeleteAt(attachmentsData, ListContainsNoCase(attachmentsData, "#URL.file#", ";"), ";")>
		<cfset thisNote.update(attachments="#attachments#")>
		<cfset result = URL.file>
	</cfif>
	<cfreturn renderWith(result)>
</cffunction>

IF you want to load the Blue Imp uploader by ajax, but you MAY have already loaded it, use the following code at the end of the layout.cfm:

<!--- make sure this is loaded for the ajax loads that occur and don't load the library. --->
<cfif NOT StructKeyExists(request, "blueImpMultiFileIncludes") OR NOT request.blueImpMultiFileIncludes>
	<cfset request.blueImpMultiFileIncludes = true>
	#stylesheetLinkTag(sources="../plugins/BlueImp/blueimp-jQuery-File-Upload/jquery.fileupload-ui",
		head=headFlag)#
	#javaScriptIncludeTag(sources="
		../plugins/BlueImp/blueimp-jQuery-File-Upload/jquery.iframe-transport,
		../plugins/BlueImp/blueimp-jQuery-File-Upload/jquery.tmpl.min,
		../plugins/BlueImp/blueimp-jQuery-File-Upload/jquery.fileupload,
		../plugins/BlueImp/blueimp-jQuery-File-Upload/jquery.load-image,
		../plugins/BlueImp/blueimp-jQuery-File-Upload/jquery.canvas-to-blob,
		../plugins/BlueImp/blueimp-jQuery-File-Upload/jquery.fileupload-ip,
		../plugins/BlueImp/blueimp-jQuery-File-Upload/jquery.fileupload-ui,
		../plugins/BlueImp/blueimp-jQuery-File-Upload/jquery.postmessage-transport,
		../plugins/BlueImp/blueimp-jQuery-File-Upload/jquery.xdr-transport,
		../plugins/BlueImp/blueimp-jQuery-File-Upload/application",
		head=headFlag)#
</cfif>